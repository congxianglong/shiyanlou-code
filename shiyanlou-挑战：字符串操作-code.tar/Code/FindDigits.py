#!/usr/bin/env python3
with open("/tmp/String.txt") as f :
    s=f.read()
res = ''

for a in s:
    if a.isdigit():
        res += a

print(res)

