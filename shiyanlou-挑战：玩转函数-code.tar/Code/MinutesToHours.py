#!/usr/bin/env python3
import sys

def Hours(n):
    if n<0:
        raise ValueError('input number cannot be negative')
    else:
        h,m=divmod(n,60)
    print("h={},m={}".format(h,m))



try:
    Hours(int(sys.argv[1]))
except:
    print('parameter Error')


